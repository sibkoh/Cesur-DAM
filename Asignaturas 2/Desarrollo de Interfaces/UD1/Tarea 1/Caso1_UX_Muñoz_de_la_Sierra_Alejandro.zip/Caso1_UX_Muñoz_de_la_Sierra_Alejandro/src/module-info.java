module Caso1_UX_Muñoz_de_la_Sierra_Alejandro {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;

	opens application to javafx.graphics, javafx.fxml;

}